/*
 *  Filename: Guest.java
 *  Date Created: 3/24/2026
 *  Date Last Modified: 3/24/2026
 *  Authors: XXX, XXX
 *  File Description:
 *      XXXX
 */

package Domain.People;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * A hotel guest who can make reservations.
 * Registered via {@link Controllers.UserController} and stored in {@link Domain.Services.UserService}.
 */
public class Guest extends User {

    private String phone;
    private String email;

    public Guest(String username, String password, String name, String phone, String email) {
        super(username, password, name);
        this.phone = phone;
        this.email = email;
    }

    @Override
    public UserRole getRole() {
        return UserRole.GUEST;
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public String getPhone() { return phone; }
    public String getEmail() { return email; }

    // ── Mutation ──────────────────────────────────────────────────────────────

    public void setPhone(String phone) { this.phone = phone; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "Guest[" + getUsername() + " | " + getName() + " | " + email + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Guest)) return false;
        Guest g = (Guest) o;
        return this.username.equals(g.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username);
    }
}
